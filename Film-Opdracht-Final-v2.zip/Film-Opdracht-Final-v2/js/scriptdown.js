
const app = document.getElementById('root');
const carouselInfo = document.getElementById('carouselInfo');



var requestURL = 'https://koopreynders.github.io/frontendvoordesigners/opdracht3/json/movies.json';

var request = new XMLHttpRequest();
request.open('GET', requestURL);

var image = document.querySelector('img');
// var cover = document.querySelector('div');
var title = document.querySelector('h2');
var genre = document.querySelector('h3');
var date = document.querySelector('p');
var actor = document.querySelector('p');
var description = document.querySelector('p');
var button = document.querySelector('button');

request.responseType = 'json';
request.send();

request.onload = function () {
    var variousMovies = request.response;
    console.log(request.response);
    // populateHeader(variousMovies);
    showMovies(variousMovies);
    showCarouselMovies(variousMovies)
    console.log(variousMovies[3].plot)
};

const showCarouselMovies = (jsonObj) => {
    console.log("jsonObj", jsonObj)
    jsonObj.map(movie => {
        const markup = 
        `
            <div class="card">
                <img class="cover"></img>
            </div>
        
        `
        document.getElementById("carousel").insertAdjacentHTML("beforeend", markup)
    })
}

const showMovies = (jsonObj) => {
    jsonObj.map(movie => {
       const markup =
            `
            <div class="infoCard">
                <h1 class="title">${movie.title}</h1>
                <p class="genre">${movie.genres}</p>
                <p class="directors">${movie.directors[0].name}</p>
                <p class="actors">${movie.actors[0].actor_name} ${movie.actors[1].actor_name}</p>
                <p class="description">${movie.plot}</p>
            </div>
        `
        document.getElementById("carouselInfo").insertAdjacentHTML("beforeend", markup)
    })
}

