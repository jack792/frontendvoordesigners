/*jslint browser: true, devel: true, eqeq: true, plusplus: true, sloppy: true, vars: true, white: true*/
/*eslint-env browser*/
/*eslint 'no-console': 0*/


//JSON aanroepen
var requestURL = 'https://koopreynders.github.io/frontendvoordesigners/opdracht3/json/movies.json';
var request = new XMLHttpRequest();
request.open('GET', requestURL);


//here we are setting the responseType to JSON, so that XHR knows that the server will be returning JSON//
request.responseType = 'json';
request.send();

// waiting for the response to return from the server, then dealing with it.//
request.onload = function () {
    var variousMovies = request.response;
    populateHeader(variousMovies);
};

//Elementen laden
function populateHeader(jsonObj) {
    console.log(jsonObj);
    for (var obj of jsonObj) { //ipv van for loop 

        var myArticle = document.createElement('article');
        var myH1 = document.createElement('h1');
        var myP = document.createElement('p');
        var myImg = document.createElement('img');
        var myH5 = document.createElement('h5');
        var myButton = document.createElement('button');

        myH1.textContent = obj.title;
        myP.textContent = obj.simple_plot;
        myImg.setAttribute('src', obj.cover);
        myH5.textContent = obj.genres;
        myButton.textContent = 'More';

        myArticle.appendChild(myH1);
        myArticle.appendChild(myP);
        myArticle.appendChild(myImg);
        myArticle.appendChild(myH5);
        myArticle.appendChild(myButton);

        document.querySelector('section').appendChild(myArticle);
    }

    var button = document.querySelector('button');

    button.addEventListener('click', function () {
        console.log('click');
        myP.textContent = obj.plot;
    });

    //function populatePlot(jsonObj) {
    //    console.log(jsonObj);
    //    for (var obj of jsonObj) { //ipv van for loop 
    //        var myP = document.createElement('p');
    //        myP.textContent = obj.plot;
    //        var header = document.querySelector('header');
    //        header.appendChild(myH1);
    //    }
}


