var card = document.getElementsByClassName ('');
var subcard = document.getElementsByClassName('');


function  down() {
    subcard.classlist.toggle('down');
    console.log('Hello there!');
}


card.addEventListener('mouseover','down');